import { Suspense, lazy } from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import paths, { rootPaths } from './paths';
import MainLayout from '../layouts/main-layout';
import AuthLayout from '../layouts/auth-layout';
import Splash from '../theme/components/loading/Splash';
import PageLoader from '../theme/components/loading/PageLoader';

const App = lazy(() => import('../App'));
const Dashboard = lazy(() => import('../pages/dashboard'));
const Login = lazy(() => import('../pages/authentication/Login'));
const Signup = lazy(() => import('../pages/authentication/Signup'));

const RouterJSX = () => {
  return (
    <Suspense fallback={<Splash />}>
      <Routes>
        {/* Main App wrapper */}
        <Route path="/" element={<App />}>
          
          {/* Auth routes */}
          <Route path={rootPaths.authRoot} element={<AuthLayout><Outlet /></AuthLayout>}>
            <Route path="login" element={<Login />} />
            <Route path="sign-up" element={<Signup />} />
          </Route>

          {/* Main layout routes */}
          <Route element={
            <MainLayout>
              <Suspense fallback={<PageLoader />}>
                <Outlet />
              </Suspense>
            </MainLayout>
          }>
            <Route index element={<Dashboard />} />
            {/* Add other pages here */}
          </Route>

        </Route>
      </Routes>
    </Suspense>
  );
};

export default RouterJSX;
