import { createTheme } from '@mui/material/styles';

// Import your custom files
import palette from './palette';
import typography from './typography';

// Import ALL Material-UI components used in the theme
import Button from '@mui/material/Button';
import ButtonBase from '@mui/material/ButtonBase';
import IconButton from '@mui/material/IconButton';
import Toolbar from '@mui/material/Toolbar';
import Chip from '@mui/material/Chip';
import Divider from '@mui/material/Divider';
import { DataGrid } from '@mui/x-data-grid'; // Note: DataGrid is from '@mui/x-data-grid'
import { MonthCalendar, YearCalendar } from '@mui/x-date-pickers'; // From date pickers
import TextField from '@mui/material/TextField';
import InputBase from '@mui/material/InputBase';
import FilledInput from '@mui/material/FilledInput';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Stack from '@mui/material/Stack';
import List from '@mui/material/List';
import MenuItem from '@mui/material/MenuItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemButton from '@mui/material/ListItemButton';
import Collapse from '@mui/material/Collapse';
import Link from '@mui/material/Link';
import Drawer from '@mui/material/Drawer';
import PaginationItem from '@mui/material/PaginationItem';
import Paper from '@mui/material/Paper';
import CssBaseline from '@mui/material/CssBaseline';

export const theme = createTheme({
  typography,
  palette,
  components: {
    MuiButton: Button,
    MuiButtonBase: ButtonBase,
    MuiIconButton: IconButton,
    MuiToolbar: Toolbar,
    MuiChip: Chip,
    MuiDivider: Divider,
    MuiDataGrid: DataGrid,
    MuiMonthCalendar: MonthCalendar,
    MuiYearCalendar: YearCalendar,
    MuiTextField: TextField,
    MuiInputBase: InputBase,
    MuiFilledInput: FilledInput,
    MuiOutlinedInput: OutlinedInput,
    MuiInputAdornment: InputAdornment,
    MuiFormControlLabel: FormControlLabel,
    MuiCheckbox: Checkbox,
    MuiStack: Stack,
    MuiList: List,
    MuiMenuItem: MenuItem,
    MuiListItemText: ListItemText,
    MuiListItemIcon: ListItemIcon,
    MuiListItemButton: ListItemButton,
    MuiCollapse: Collapse,
    MuiLink: Link,
    MuiDrawer: Drawer,
    MuiPaginationItem: PaginationItem,
    MuiPaper: Paper,
    MuiCssBaseline: CssBaseline,
  },
  // customShadows has been removed
  spacing: 8,
});